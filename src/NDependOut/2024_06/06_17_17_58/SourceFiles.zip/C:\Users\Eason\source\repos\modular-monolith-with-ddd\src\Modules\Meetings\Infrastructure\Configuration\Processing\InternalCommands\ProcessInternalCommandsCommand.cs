﻿using CompanyName.MyMeetings.Modules.Meetings.Application.Contracts;

namespace CompanyName.MyMeetings.Modules.Meetings.Infrastructure.Configuration.Processing.InternalCommands
{
    internal class ProcessInternalCommandsCommand : CommandBase, IRecurringCommand
    {
    }
}