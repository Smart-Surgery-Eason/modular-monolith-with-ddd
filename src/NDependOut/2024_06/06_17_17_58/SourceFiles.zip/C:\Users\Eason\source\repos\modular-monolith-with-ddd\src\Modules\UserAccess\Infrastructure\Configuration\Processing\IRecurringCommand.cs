﻿namespace CompanyName.MyMeetings.Modules.UserAccess.Infrastructure.Configuration.Processing
{
    public interface IRecurringCommand
    {
    }
}