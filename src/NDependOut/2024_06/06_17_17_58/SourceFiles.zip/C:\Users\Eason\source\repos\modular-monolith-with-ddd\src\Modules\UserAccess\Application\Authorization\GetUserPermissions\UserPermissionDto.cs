﻿namespace CompanyName.MyMeetings.Modules.UserAccess.Application.Authorization.GetUserPermissions
{
    public class UserPermissionDto
    {
        public string Code { get; set; }
    }
}