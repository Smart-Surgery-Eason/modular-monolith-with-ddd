﻿namespace CompanyName.MyMeetings.Modules.Registrations.IntegrationEvents;

public class Class1
{
}