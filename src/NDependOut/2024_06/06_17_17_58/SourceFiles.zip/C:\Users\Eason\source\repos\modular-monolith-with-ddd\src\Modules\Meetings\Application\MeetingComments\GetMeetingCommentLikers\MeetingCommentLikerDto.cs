﻿namespace CompanyName.MyMeetings.Modules.Meetings.Application.MeetingComments.GetMeetingCommentLikers
{
    public class MeetingCommentLikerDto
    {
        public Guid Id { get; set; }

        public string Name { get; set; }
    }
}