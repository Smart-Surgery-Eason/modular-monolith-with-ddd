﻿namespace CompanyName.MyMeetings.Modules.UserAccess.Application.Contracts
{
    public class Roles
    {
        public const string Admin = "Admin";
        public const string User = "User";
    }
}