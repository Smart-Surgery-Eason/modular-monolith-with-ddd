﻿namespace CompanyName.MyMeetings.Modules.Meetings.Infrastructure.Configuration.Processing
{
    public interface IRecurringCommand
    {
    }
}