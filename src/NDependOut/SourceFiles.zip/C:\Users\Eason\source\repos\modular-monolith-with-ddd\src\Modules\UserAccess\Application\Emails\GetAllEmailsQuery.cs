﻿using CompanyName.MyMeetings.Modules.UserAccess.Application.Contracts;

namespace CompanyName.MyMeetings.Modules.UserAccess.Application.Emails
{
    public class GetAllEmailsQuery : QueryBase<List<EmailDto>>
    {
    }
}