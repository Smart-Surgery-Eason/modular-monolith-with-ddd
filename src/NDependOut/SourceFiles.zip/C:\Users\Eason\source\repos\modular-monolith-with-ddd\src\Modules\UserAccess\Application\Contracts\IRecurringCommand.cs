﻿namespace CompanyName.MyMeetings.Modules.UserAccess.Application.Contracts
{
    public interface IRecurringCommand
    {
    }
}