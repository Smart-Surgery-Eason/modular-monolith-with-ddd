﻿using CompanyName.MyMeetings.BuildingBlocks.Domain;

namespace CompanyName.MyMeetings.Modules.Administration.Domain.MeetingGroupProposals.Events
{
    internal class MeetingGroupProposalShowDomainEvent : DomainEventBase
    {
        public MeetingGroupProposalShowDomainEvent()
        {
        }
    }
}
