﻿namespace CompanyName.MyMeetings.Modules.Meetings.Domain.Members
{
    public interface IMemberContext
    {
        MemberId MemberId { get; }
    }
}