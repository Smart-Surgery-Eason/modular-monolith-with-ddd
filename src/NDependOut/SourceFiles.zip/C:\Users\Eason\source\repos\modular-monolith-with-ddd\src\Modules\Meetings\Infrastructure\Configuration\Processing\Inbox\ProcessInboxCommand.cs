﻿using CompanyName.MyMeetings.Modules.Meetings.Application.Contracts;

namespace CompanyName.MyMeetings.Modules.Meetings.Infrastructure.Configuration.Processing.Inbox
{
    public class ProcessInboxCommand : CommandBase, IRecurringCommand
    {
    }
}