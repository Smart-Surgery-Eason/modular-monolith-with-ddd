﻿using CompanyName.MyMeetings.Modules.Meetings.Application.Contracts;

namespace CompanyName.MyMeetings.Modules.Meetings.Application.Meetings.GetAuthenticatedMemberMeetings
{
    public class GetAuthenticatedMemberMeetingsQuery : QueryBase<List<MemberMeetingDto>>
    {
    }
}