﻿using CompanyName.MyMeetings.Modules.UserAccess.Application.Contracts;

namespace CompanyName.MyMeetings.Modules.UserAccess.Infrastructure.Configuration.Processing.Inbox
{
    public class ProcessInboxCommand : CommandBase, IRecurringCommand
    {
    }
}